package es.ucm.tp1.actions;

import es.ucm.tp1.logic.Game;

public interface InstantAction {
	void execute(Game game);
}
